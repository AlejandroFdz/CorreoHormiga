
<?php $content = json_decode($component->content, true); ?>

<div id="<?php echo e($component->name); ?>" class="component" style="
        margin:<?php echo e($component->margin); ?>px;
        padding:<?php echo e($component->padding); ?>px;
        background-color:<?php echo e($content['component']['bg_color']); ?>;
        background-image:url(<?php echo e(url('storage')); ?>/<?php echo e($content['component']['bg_img']); ?>);
        text-align:<?php echo e($content['component']['text_align']); ?>;
        ">

    <div data-component="<?php echo e($component->name); ?>" class="btn-settings">
        <i id="header_settings" class="fa fa-cog comp-settings btn btn-default" aria-hidden="true"></i>
    </div>

    <?php if( isset($content['logo']) ): ?>
        <img src="<?php echo e(url('storage')); ?>/<?php echo e($content['logo']['properties']['picture']); ?>" style="
            margin-top:<?php echo e($content['logo']['styles']['margin_top']); ?>px;
            margin-bottom:<?php echo e($content['logo']['styles']['margin_bottom']); ?>px;
            width:25%;
        " id="logo_image">
    <?php endif; ?>

    <?php if( isset($content['title']) ): ?>
        <h1 id="header_title" style="
            font-size:<?php echo e($content['title']['styles']['font_size']); ?>px;
            margin-top:<?php echo e($content['title']['styles']['margin_top']); ?>px;
            margin-bottom:<?php echo e($content['title']['styles']['margin_bottom']); ?>px;
            color:<?php echo e($content['title']['styles']['color']); ?>;
        ">
            <?php echo e($content['title']['properties']['text']); ?>

        </h1>
    <?php endif; ?>


</div>