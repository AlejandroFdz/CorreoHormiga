<table width="100%" cellspacing="0" cellpadding="0" border="0">
  <tbody>
    <tr>

      <?php $__currentLoopData = $components; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $component): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      	<?php if( $component->name != "footer" ): ?>
        	<?php echo $__env->make('components/email/' . $component->name, ['component' => $component, 'campaign_data' => $campaign_data], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <!-- Footer -->

		<?php $__currentLoopData = $components; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $component): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	      	<?php if($component->name == "footer"): ?>

	      		<?php $content = json_decode($component->content, true); ?>

		    	<div id="<?php echo e($component->name); ?>" class="component" style="
			        margin:<?php echo e($component->margin); ?>px;
			        background-color:<?php echo e($content['component']['bg_color']); ?>;
			        text-align:<?php echo e($content['component']['text_align']); ?>;
			        display:inline-block;
			        width:100%;
			        padding:20px;
			        ">

				    <?php if(isset($content['social_media'])): ?>

				        <div>

				            <?php $__currentLoopData = $content['social_media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                <a href="http://correo.hormiga/email/clicked/<?php echo e($campaign_data['list_id']); ?>/<?php echo e($campaign_data['subscriber_id']); ?>/<?php echo e($social['url']); ?>" target="_blank" style="
				                        margin-left:<?php echo e($social['margin_left']); ?>px;
				                        margin-right:<?php echo e($social['margin_right']); ?>px;
				                        text-decoration: none;" id="social_footer_<?php echo e($key); ?>">
				                    <img src="<?php echo e(asset('imgs/templates/components/footer/social')); ?>/<?php echo e($social['icon']); ?>" width="22" height="22">
				                </a>
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				            <hr>

				            <span style="line-height:27px;">
				                Copyright © <strong id="footer_company"><?php echo e($company); ?></strong>,<br>
				                ¿Quieres darte de baja de éste boletín de noticias?<br>
				                Puedes hacerlo pulsando <a href="<?php echo e(url('contacts/unsubscribe')); ?>/<?php echo e($campaign_data['subscriber_id']); ?>" target="_blank" style="text-decoration:none;color:#fff;">aquí</a>.
				            </span>

				        </div>

				    <?php endif; ?>

				</div>

			<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<!-- End Footer -->
      
    </tr>
  </tbody>
</table>

<img src='http://correo.hormiga/email/opened/<?php echo e($campaign_data['list_id']); ?>/<?php echo e($campaign_data['subscriber_id']); ?>/<?php echo e($campaign_data['emails_sended']); ?>' style='width:1px;height:1px;'>
