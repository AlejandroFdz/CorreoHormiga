<?php $content = json_decode($component->content, true); ?>

<div id="<?php echo e($component->name); ?>" class="component" style="
        margin:<?php echo e($component->margin); ?>px;
        padding:<?php echo e($component->padding); ?>px;
        background-color:<?php echo e($content['component']['bg_color']); ?>;
        text-align:<?php echo e($content['component']['text_align']); ?>;
        ">

    <div data-component="<?php echo e($component->name); ?>" class="btn-settings">
        <i id="full_button_settings" class="fa fa-cog comp-settings btn btn-default" aria-hidden="true"></i>
    </div>

    <?php if( isset($content['button']) ): ?>
        <a href="<?php echo e($content['button']['link']); ?>" id="full_button_text" style="
            background-color:<?php echo e($content['button']['bg_color']); ?>;
                color:<?php echo e($content['button']['color']); ?>;
                font-size:<?php echo e($content['button']['font_size']); ?>px;
                padding:<?php echo e($content['button']['padding']); ?>px;
                border-radius:<?php echo e($content['button']['border_radius']); ?>px;
        ">
            <?php echo e($content['button']['text']); ?>

        </a>
    <?php endif; ?>

</div>
