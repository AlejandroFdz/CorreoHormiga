<?php $content = json_decode($component->content, true); ?>

<div id="<?php echo e($component->name); ?>" class="component" style="
        margin:<?php echo e($component->margin); ?>px;
        padding:<?php echo e($component->padding); ?>px;
        background-color:<?php echo e($content['component']['bg_color']); ?>;
        text-align:<?php echo e($content['component']['text_align']); ?>;
        display:inline-block;
        width:100%;
        ">

    <?php if(isset($content['social_media'])): ?>

        <div>

            <?php $__currentLoopData = $content['social_media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($social['url']); ?>" target="_blank" style="
                        margin-left:<?php echo e($social['margin_left']); ?>px;
                        margin-right:<?php echo e($social['margin_right']); ?>px;
                        " id="social_footer_<?php echo e($key); ?>">
                    <img src="<?php echo e(asset('imgs/templates/components/footer/social')); ?>/<?php echo e($social['icon']); ?>" width="22" height="22">
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <hr>

            <span style="line-height:27px;">
                Copyright © <strong id="footer_company">[EL NOMBRE DE TU EMPRESA]</strong>,<br>
                ¿Quieres darte de baja de éste boletín de noticias?<br>
                Puedes hacerlo pulsando <a href="<?php echo e(url('contacts/unsubscribe')); ?>/<?php echo e($campaign_data['subscriber_id']); ?>" target="_blank">aquí</a>.
            </span>

        </div>

    <?php endif; ?>

</div>
