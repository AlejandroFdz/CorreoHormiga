<?php $__env->startComponent('mail::message'); ?>
# Correo Hormiga

Todos los correos se enviaron a sus destinatarios con éxito. Podrá consultar las estadísticas de aperturas e interacciones
desde su cuenta de usuario en Correo Hormiga. 

<?php $__env->startComponent('mail::button', ['url' => 'http://correo.hormiga']); ?>
Correo Hormiga
<?php echo $__env->renderComponent(); ?>

Gracias por usar nuestro servicio,
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
