@extends('layouts.subscriptor.base')

@section('title')
  <h1>Dejaste de estar subscrito</h1>
@endsection

@section('content')

	<div class="row text-center">

		<p>
			Has dejado de estar subscrito a este boletín de noticias. Ya no recibirás más correos como estos.
		</p>
		
	</div>

@endsection

@section('scripts')
@endsection