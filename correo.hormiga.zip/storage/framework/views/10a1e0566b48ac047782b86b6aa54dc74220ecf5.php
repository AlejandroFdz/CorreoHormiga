<?php $__env->startComponent('mail::message'); ?>
# Nuevo ticket creado en **Correo Hormiga**

Se ha creado un nuevo ticket en **Correo Hormiga**. Accede para revisarlo.

<?php $__env->startComponent('mail::button', ['url' => 'http://correo.hormiga/tickets']); ?>
Correo Hormiga
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
