<?php $content = json_decode($component->content, true); ?>

<div id="<?php echo e($component->name); ?>" class="component" style="
        margin:<?php echo e($component->margin); ?>px;
        padding:<?php echo e($component->padding); ?>px;
        background-color:<?php echo e($content['component']['bg_color']); ?>;
        text-align:<?php echo e($content['component']['text_align']); ?>;
        ">

    <div data-component="<?php echo e($component->name); ?>" class="btn-settings">
        <i class="fa fa-cog comp-settings btn btn-default" aria-hidden="true"></i>
    </div>

    <?php if( isset($content['featured_picture']) ): ?>
        <img src="<?php echo e(url('storage')); ?>/<?php echo e($content['featured_picture']['picture']); ?>" id="picture_two_columns_featured_picture" style="width:100%;">
    <?php endif; ?>

    <?php if( isset($content['title']) ): ?>
        <h3 id="picture_two_columns_title" style="
                font-size:<?php echo e($content['title']['styles']['font_size']); ?>px;
                margin-top:<?php echo e($content['title']['styles']['margin_top']); ?>px;
                color:<?php echo e($content['title']['styles']['color']); ?>

                font-style: <?php echo e($content['title']['styles']['font-style']); ?>;
                ">
            <?php echo e($content['title']['properties']['text']); ?>

        </h3>
    <?php endif; ?>

    <?php if( isset($content['columns']) ): ?>
        <div style="display:inline-block;color:#808080;font-size:16px;">
            <div id="column_text_1" style="width:49%;float:left;">
                <?php echo e($content['columns']['column_1']['text']); ?>

            </div>
            <div id="column_text_2" style="width:49%;float:right;">
                <?php echo e($content['columns']['column_2']['text']); ?>

            </div>
        </div>
    <?php endif; ?>


</div>
